function register() {
    // Basic validation
    var fullname = document.getElementById('fullname').value;
    var phone= document.getElementById('fullname').value;
    var birthday= document.getElementById('fullname').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var gender = document.getElementById('gender').value;
  
    // Perform server-side registration logic here
    // ...
  
    alert('Registration successful!');
  }
  
  function login() {
    // Basic validation
    var loginEmail = document.getElementById('loginEmail').value;
    var loginPassword = document.getElementById('loginPassword').value;
  
    // Perform server-side login logic here
    // ...
  
    alert('Login successful!');
  }
  
  function switchForm(formId) {
    var forms = document.querySelectorAll('.container form');
    forms.forEach(function(form) {
      form.classList.remove('active-form');
    });
  
    document.getElementById(formId).classList.add('active-form');
  }
  